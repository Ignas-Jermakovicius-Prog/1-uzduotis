#pragma once
#include "vidmed.h"
#include "generavimas.h"
#include "build_lib.h"

using namespace std;

void kadarytvek(string raide, int strategija);