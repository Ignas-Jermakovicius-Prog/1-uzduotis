#include "stud.h"
#include "build_lib.h"
#include "generavimas.h"

using namespace std;

void kadarytlist(string raide, int strategija);