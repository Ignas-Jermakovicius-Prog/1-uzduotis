#pragma once
#include "stud.h"
#include "build_lib.h"
#include "generavimas.h"

using namespace std;

void kadarytabiem(int strategija);
