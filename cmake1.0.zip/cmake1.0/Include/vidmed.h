#pragma once
#include "build_lib.h"
#include "stud.h"

using namespace std;

float vid(vector<int> paz);
float med(vector<int> paz);